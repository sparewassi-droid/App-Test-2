import React, { useEffect } from 'react';

interface BottomDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: React.ReactNode;
}

export const BottomDrawer: React.FC<BottomDrawerProps> = ({
  isOpen,
  onClose,
  children,
  title,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      {/* Dim backdrop with blur */}
      <div
        className="fixed inset-0 bg-[#07170E]/50 backdrop-blur-xs transition-opacity duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer content */}
      <div
        role="dialog"
        aria-modal="true"
        className="relative z-10 w-full max-w-[560px] mx-auto glass-surface rounded-t-[32px] border-t border-x border-[#D4AF37]/40 p-6 pb-10 safe-bottom shadow-2xl animate-drawer-up max-h-[90dvh] overflow-y-auto"
      >
        {/* Drag handle */}
        <div className="w-12 h-1.5 bg-[#D4AF37]/40 rounded-full mx-auto mb-4" />

        {title && <div className="mb-4">{title}</div>}

        {children}
      </div>

      <style>{`
        @keyframes drawerUp {
          0% {
            transform: translateY(100%);
          }
          100% {
            transform: translateY(0);
          }
        }
        .animate-drawer-up {
          animation: drawerUp 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};
