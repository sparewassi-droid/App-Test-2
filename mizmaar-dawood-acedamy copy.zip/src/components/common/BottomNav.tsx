import React from 'react';
import { Home, Map as MapIcon, Swords, Shield, BookOpen } from 'lucide-react';
import { soundService } from '../../utils/audio';

export type MainTab = 'home' | 'map' | 'duels' | 'grownups' | 'verse';

interface BottomNavProps {
  currentTab: MainTab;
  onSelectTab: (tab: MainTab) => void;
  unlockedModuleCount?: number;
  onOpenVerse?: () => void;
  isVerseOpen?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  unlockedModuleCount = 1,
  onOpenVerse,
  isVerseOpen = false,
}) => {
  const tabs = [
    {
      id: 'home' as MainTab,
      label: 'Home',
      icon: Home,
    },
    {
      id: 'map' as MainTab,
      label: 'Quest Map',
      icon: MapIcon,
      badge: `${unlockedModuleCount} Open`,
    },
    {
      id: 'verse' as MainTab,
      label: 'Daily Verse',
      icon: BookOpen,
    },
    {
      id: 'duels' as MainTab,
      label: 'Duels',
      icon: Swords,
    },
    {
      id: 'grownups' as MainTab,
      label: 'Grown-ups',
      icon: Shield,
    },
  ];

  return (
    <nav
      aria-label="Bottom Navigation"
      className="shrink-0 w-full bg-[#FAF5EA] border-t-2 border-[#D4AF37] px-1 sm:px-4 bottom-nav-safe z-40 select-none shadow-[0_-4px_25px_rgba(0,0,0,0.12)]"
    >
      <div className="max-w-[680px] mx-auto flex items-center justify-around gap-0.5 sm:gap-2">
        {tabs.map((tab) => {
          const isActive = tab.id === 'verse' ? isVerseOpen : !isVerseOpen && currentTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                soundService.playTap();
                if (tab.id === 'verse') {
                  if (onOpenVerse) {
                    onOpenVerse();
                  } else {
                    onSelectTab('verse');
                  }
                } else {
                  onSelectTab(tab.id);
                }
              }}
              className={`relative flex-1 min-w-0 py-1 sm:py-2 px-0.5 sm:px-2 rounded-xl sm:rounded-2xl flex flex-col items-center justify-center gap-0.5 sm:gap-1 transition-all duration-150 active:scale-95 cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-[#1A3D7C] via-[#24509A] to-[#10264F] text-white shadow-md shadow-blue-950/20 border border-[#E5B842]/50 font-bold scale-[1.02]'
                  : 'text-[#1A3D7C] hover:bg-amber-100/50'
              }`}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  size={20}
                  strokeWidth={isActive ? 2.6 : 2.2}
                  className={isActive ? 'text-[#F5C542]' : 'text-[#1A3D7C]'}
                />
                {tab.badge && !isActive && (
                  <span className="absolute -top-1.5 -right-3 text-[9px] font-black bg-gradient-to-r from-[#D4AF37] to-[#B8892B] text-white px-1.5 py-0.2 rounded-full border border-white/60 shadow-xs">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[9.5px] sm:text-[11px] leading-tight text-center truncate max-w-full tracking-tight ${
                  isActive ? 'font-black text-[#FFF0A6]' : 'font-bold text-[#1A3D7C]'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#F5C542] -mt-0.5 shadow-[0_0_6px_#F5C542]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
