import React, { useState } from 'react';
import {
  Compass,
  Map as MapIcon,
  Swords,
  Star,
  Sparkles,
  Volume2,
  VolumeX,
  CheckCircle2,
  ChevronRight,
  Zap,
  Edit2,
  Check,
  Flame,
  ArrowRight,
  Palette,
  BookOpen,
  Shield,
  Play,
  Trophy,
} from 'lucide-react';
import { ProgressState, AgeGroup, Tier } from '../../types';
import { THEME_A_MODULES, THEME_B_MODULES } from '../../data/modules';
import { TreasureChestSvg } from './QuestMap/TreasureChestSvg';
import { soundService } from '../../utils/audio';

interface DashboardHomeProps {
  progress: ProgressState;
  theme?: 'default' | 'sage' | 'light-mustard' | 'dark-purple' | 'dark-emerald';
  onToggleTheme?: () => void;
  onOpenMap: () => void;
  onOpenDuels: () => void;
  onOpenGrownUps: () => void;
  onChangeAgeGroup: (age: AgeGroup) => void;
  onUpdateUsername: (name: string) => void;
  onOpenStage?: (moduleId: string, tier: Tier) => void;
  onOpenVerse?: () => void;
}

export const DashboardHome: React.FC<DashboardHomeProps> = ({
  progress,
  theme = 'default',
  onToggleTheme,
  onOpenMap,
  onOpenDuels,
  onOpenGrownUps,
  onChangeAgeGroup,
  onUpdateUsername,
  onOpenStage,
  onOpenVerse,
}) => {
  const [isMuted, setIsMuted] = useState(soundService.isMuted());
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(progress.username);

  const toggleSound = () => {
    const next = soundService.toggleMute();
    setIsMuted(next);
  };

  const currentModules = progress.ageGroup === '7-11' ? THEME_A_MODULES : THEME_B_MODULES;

  // Count unlocked modules
  const unlockedCount = currentModules.filter(
    (m, idx) =>
      progress.grownUps.allRegionsUnlocked ||
      idx === 0 ||
      progress.modules[currentModules[idx - 1]?.id]?.stages.moderate.passed
  ).length;

  // Next active module to focus on
  const nextModuleIndex = currentModules.findIndex((m, idx) => {
    const isUnlocked =
      progress.grownUps.allRegionsUnlocked ||
      idx === 0 ||
      progress.modules[currentModules[idx - 1]?.id]?.stages.moderate.passed;
    const modProg = progress.modules[m.id];
    const isMastered =
      modProg?.stages.easy.passed &&
      modProg?.stages.moderate.passed &&
      modProg?.stages.difficult.passed;
    return isUnlocked && !isMastered;
  });

  const activeModuleIndex = nextModuleIndex !== -1 ? nextModuleIndex : 0;
  const nextModule = currentModules[activeModuleIndex] || currentModules[0];
  const activeProg = progress.modules[nextModule.id];
  const activeStars =
    (activeProg?.stages.easy.stars || 0) +
    (activeProg?.stages.moderate.stars || 0) +
    (activeProg?.stages.difficult.stars || 0);

  // Determine which stage to play next for the active module
  const nextTier: Tier = !activeProg?.stages.easy.passed
    ? 'easy'
    : !activeProg?.stages.moderate.passed
    ? 'moderate'
    : 'difficult';

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (nameInput.trim()) {
      onUpdateUsername(nameInput.trim());
      setIsEditingName(false);
      soundService.playTap();
    }
  };

  return (
    <div className="h-full overflow-y-auto overscroll-contain px-3 sm:px-6 md:px-8 py-3 sm:py-5 max-w-[960px] mx-auto w-full select-none safe-top safe-left safe-right space-y-3.5 sm:space-y-5 pb-28 sm:pb-32 text-[#0A192F]">
      {/* 1. TOP BAR (UNCHANGED IN LIGHT & DARK PURPLE MODE) */}
      <header className="bg-[#FAF5EA] rounded-2xl border-2 border-[#D4AF37]/50 p-2 sm:p-3 shadow-xs flex items-center justify-between gap-2 transition-all">
        {/* Scholar Profile */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#1A3D73] via-[#2A5CAA] to-[#10264F] text-[#FFF0A6] flex items-center justify-center font-black text-sm border border-[#E5B842] shadow-sm">
              {progress.username.substring(0, 2).toUpperCase()}
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#D4AF37] border-2 border-white flex items-center justify-center text-[8px] text-[#10264F] font-black shadow-xs">
              ✓
            </div>
          </div>

          <div className="flex flex-col min-w-0">
            {isEditingName ? (
              <form onSubmit={handleSaveName} className="flex items-center gap-1.5">
                <input
                  type="text"
                  autoFocus
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-32 sm:w-36 px-2 py-0.5 text-xs sm:text-sm font-bold rounded-lg bg-white text-[#0A192F] border-2 border-[#E5B842] focus:outline-none focus:ring-2 focus:ring-[#2A5CAA] shadow-xs scholar-name-input"
                  aria-label="Student name"
                  placeholder="Enter name..."
                />
                <button
                  type="submit"
                  aria-label="Save name"
                  title="Save name"
                  className="w-6 h-6 bg-[#1A3D73] hover:bg-[#2A5CAA] text-[#FFF0A6] rounded-lg flex items-center justify-center text-xs border border-[#E5B842] shadow-xs shrink-0 active:scale-95 transition-transform"
                >
                  <Check size={14} />
                </button>
              </form>
            ) : (
              <div
                className="flex items-center gap-1.5 cursor-pointer group"
                onClick={() => {
                  soundService.playTap();
                  setIsEditingName(true);
                }}
                title="Click to change scholar name"
              >
                <h1 className="text-sm sm:text-base font-black text-[#0A192F] scholar-name-display leading-tight truncate">
                  {progress.username}
                </h1>
                <Edit2 size={13} className="text-[#8C681E] scholar-name-edit-icon group-hover:text-[#1A3D73] shrink-0 transition-colors" />
              </div>
            )}
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[10px] text-[#8C681E] scholar-level-badge font-extrabold bg-[#FDF5E2] border border-[#DEBE6B] px-1.5 py-0.2 rounded-md flex items-center gap-1">
                <Trophy size={10} className="text-[#D4AF37]" />
                Lv. {progress.level} {progress.levelTitle}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Utility Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Age Group Switcher */}
          <button
            type="button"
            onClick={() => {
              soundService.playTap();
              onChangeAgeGroup(progress.ageGroup === '7-11' ? '11-14' : '7-11');
            }}
            title={`Age Track: ${progress.ageGroup === '7-11' ? 'Explorer (7–11 yrs)' : 'Scholar (11–14 yrs)'}. Click to switch.`}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-xs font-black shadow-xs transition-all cursor-pointer active:scale-95 ${
              progress.ageGroup === '7-11'
                ? 'bg-gradient-to-r from-[#1A3D73] to-[#2556A3] border-[#E5B842]/70 text-white'
                : 'bg-gradient-to-r from-[#C99726] to-[#B8892B] border-[#FFF0A6]/70 text-white'
            }`}
          >
            <Compass size={14} className={progress.ageGroup === '7-11' ? 'text-[#93C5FD]' : 'text-white'} />
            <span className="font-black">{progress.ageGroup === '7-11' ? '7–11' : '11–14'}</span>
          </button>

          {/* Theme Switcher: Toggles Sage (#9DB297) Background vs Classic Sand */}
          {onToggleTheme && (
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={
                theme === 'sage'
                  ? 'Switch to Classic Sand theme'
                  : 'Switch to Sage (#9DB297) background'
              }
              title={
                theme === 'sage'
                  ? 'Active: Sage (#9DB297) Background. Click for Classic Sand'
                  : 'Active: Classic Sand. Click for Sage (#9DB297) Background'
              }
              className={`w-8 h-8 rounded-xl border-2 flex items-center justify-center shadow-xs cursor-pointer active:scale-95 transition-all select-none ${
                theme === 'sage'
                  ? 'bg-[#9DB297] border-[#557250] text-[#10264F] shadow-[0_0_8px_rgba(157,178,151,0.6)]'
                  : 'bg-white border-[#D4AF37]/50 text-[#1A3D73] hover:text-[#8C681E]'
              }`}
            >
              <Palette size={16} />
            </button>
          )}

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={toggleSound}
            aria-label={isMuted ? 'Unmute' : 'Mute'}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="w-8 h-8 rounded-xl bg-white border border-[#D4AF37]/50 flex items-center justify-center text-[#1A3D73] hover:text-[#8C681E] shadow-xs active:scale-95 transition-all"
          >
            {isMuted ? <VolumeX size={15} className="text-[#1D4ED8]" /> : <Volume2 size={15} className="text-[#1D4ED8]" />}
          </button>

          {/* Grown-ups Corner shortcut */}
          <button
            type="button"
            onClick={onOpenGrownUps}
            title="Grown-ups Corner"
            aria-label="Grown-ups Corner"
            className="w-8 h-8 rounded-xl bg-white border border-[#D4AF37]/50 flex items-center justify-center text-[#1A3D73] hover:text-[#8C681E] shadow-xs active:scale-95 transition-all"
          >
            <Shield size={15} className="text-[#1D4ED8]" />
          </button>
        </div>
      </header>

      {/* 2. FIRST DISPLAY BOX: SCHOLAR SALUTATION (CLEAN & HIGH-CONTRAST) */}
      <section className="bg-[#FAF5EA] rounded-2xl sm:rounded-3xl border-2 border-[#D4AF37]/50 p-4 sm:p-5 shadow-sm transition-all flex items-center gap-3.5 sm:gap-4">
        {/* Scholar Avatar Badge */}
        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-[#1A3D7C] to-[#2556A3] text-[#FFF0A6] flex items-center justify-center font-black text-lg sm:text-xl border-2 border-[#E5B842] shadow-sm shrink-0">
          {progress.username.substring(0, 2).toUpperCase()}
        </div>

        {/* Welcome Text */}
        <div className="min-w-0 flex-1">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-[#0A192F] tracking-tight leading-tight">
            Welcome back, <span className="text-[#1A3D7C]">{progress.username}</span>!
          </h2>
        </div>
      </section>

      {/* 3. ACTIVE QUEST EXPEDITION CARD (ICON-FIRST HERO) */}
      <section
        onClick={onOpenMap}
        className="relative rounded-3xl bg-gradient-to-br from-[#0F2347] via-[#1A3D7C] to-[#24509A] text-white p-4 sm:p-5 shadow-xl card-modern cursor-pointer overflow-hidden border border-[#E5B842]/40 select-none group"
      >
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          {/* Left: Quest Icon & Title */}
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Treasure Chest Icon */}
            <div className="relative shrink-0">
              <div className="p-2 rounded-2xl bg-white/10 backdrop-blur-md border border-[#E5B842]/50 shadow-inner flex items-center justify-center group-hover:scale-105 transition-transform">
                <TreasureChestSvg
                  state={activeStars >= 9 ? 'mastered' : 'active'}
                  size={52}
                  isCurrent={true}
                />
              </div>
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#D4AF37] to-[#B8892B] text-white text-[9px] font-black px-2 py-0.2 rounded-full border border-white/60 whitespace-nowrap shadow-xs">
                Quest {activeModuleIndex + 1}
              </div>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#FCD34D] bg-white/10 px-2 py-0.2 rounded-full">
                  {nextModule.regionName}
                </span>
              </div>

              <h3 className="text-base sm:text-lg md:text-xl font-black text-white flex items-center gap-2 mt-0.5 leading-tight truncate">
                <span>{nextModule.title}</span>
                {nextModule.arabicSubtitle && (
                  <span className="font-amiri text-sm text-[#FDE68A] bg-black/30 px-2 py-0.2 rounded border border-[#E5B842]/30 shrink-0">
                    {nextModule.arabicSubtitle}
                  </span>
                )}
              </h3>

              {/* 3 Visual Trial Checkpoint Icons */}
              <div className="flex items-center gap-2 mt-2">
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                  activeProg?.stages.easy.passed ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/40' : 'bg-white/10 text-white/80'
                }`}>
                  <Zap size={11} /> Easy {activeProg?.stages.easy.passed ? '✓' : ''}
                </div>
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                  activeProg?.stages.moderate.passed ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/40' : 'bg-white/10 text-white/80'
                }`}>
                  <Shield size={11} /> Core {activeProg?.stages.moderate.passed ? '✓' : ''}
                </div>
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                  activeProg?.stages.difficult.passed ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/40' : 'bg-white/10 text-white/80'
                }`}>
                  <Trophy size={11} /> Vault {activeProg?.stages.difficult.passed ? '✓' : ''}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Embark Button */}
          <div className="shrink-0 flex items-center sm:flex-col justify-end gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                soundService.playTap();
                if (onOpenStage) {
                  onOpenStage(nextModule.id, nextTier);
                } else {
                  onOpenMap();
                }
              }}
              className="w-full sm:w-auto py-2.5 px-5 rounded-2xl bg-gradient-to-r from-[#F5C542] via-[#E5B842] to-[#D4AF37] hover:brightness-105 text-[#0A192F] text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer border border-white/60"
            >
              <Play size={15} fill="currentColor" className="shrink-0" />
              <span>Embark</span>
              <ArrowRight size={14} className="shrink-0" />
            </button>
            <span className="text-[10px] text-white/70 font-semibold text-center hidden sm:block">
              ★ {activeStars}/9 Stars
            </span>
          </div>
        </div>
      </section>

      {/* 4. ACTION HUB: 3 ICON-DRIVEN INTERACTIVE CARDS (UNCHANGED BOXES) */}
      <section className="grid grid-cols-3 gap-2.5 sm:gap-3.5">
        {/* Card 1: Daily Sunnah */}
        <div
          onClick={onOpenMap}
          className="bg-[#FAF5EA] p-3 sm:p-4 rounded-2xl border-2 border-[#E5B842]/50 hover:border-[#D4AF37] shadow-xs hover:shadow-md flex flex-col justify-between items-center text-center gap-2 cursor-pointer card-modern transition-all group"
        >
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-[#FEFCE8] border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-2xs group-hover:scale-105 transition-transform">
            <Sparkles size={22} className="text-[#D4AF37]" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-[#0A192F] leading-tight">
              Daily Goal
            </h4>
            <span className="text-[10px] font-bold text-[#8C681E] block mt-0.5">
              +{progress.todaysQuest.rewardXp} XP
            </span>
          </div>
          <div className="w-6 h-6 rounded-full bg-white border border-[#E5B842]/60 flex items-center justify-center text-[#8C681E]">
            {progress.todaysQuest.completed ? <CheckCircle2 size={14} className="text-emerald-600" /> : <ChevronRight size={14} />}
          </div>
        </div>

        {/* Card 2: Duels Arena */}
        <div
          onClick={onOpenDuels}
          className="bg-[#FAF5EA] p-3 sm:p-4 rounded-2xl border-2 border-[#2A5CAA]/40 hover:border-[#1A3D73] shadow-xs hover:shadow-md flex flex-col justify-between items-center text-center gap-2 cursor-pointer card-modern transition-all group"
        >
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-[#EFF6FF] border border-[#93C5FD] flex items-center justify-center text-[#2563EB] shadow-2xs group-hover:scale-105 transition-transform">
            <Swords size={22} className="text-[#1D4ED8]" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-[#0A192F] leading-tight">
              Speed Duels
            </h4>
            <span className="text-[10px] font-bold text-[#1D4ED8] block mt-0.5">
              Bot Guides
            </span>
          </div>
          <div className="w-6 h-6 rounded-full bg-white border border-[#93C5FD] flex items-center justify-center text-[#1D4ED8]">
            <ChevronRight size={14} />
          </div>
        </div>

        {/* Card 3: Daily Verse */}
        <div
          onClick={() => {
            soundService.playTap();
            if (onOpenVerse) onOpenVerse();
          }}
          className="bg-[#FAF5EA] p-3 sm:p-4 rounded-2xl border-2 border-[#16A34A]/40 hover:border-[#15803D] shadow-xs hover:shadow-md flex flex-col justify-between items-center text-center gap-2 cursor-pointer card-modern transition-all group"
        >
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-[#F0FDF4] border border-[#86EFAC] flex items-center justify-center text-[#16A34A] shadow-2xs group-hover:scale-105 transition-transform">
            <BookOpen size={22} className="text-[#15803D]" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-[#0A192F] leading-tight">
              Daily Ayah
            </h4>
            <span className="text-[10px] font-bold text-[#15803D] block mt-0.5">
              Reflection
            </span>
          </div>
          <div className="w-6 h-6 rounded-full bg-white border border-[#86EFAC] flex items-center justify-center text-[#15803D]">
            <ChevronRight size={14} />
          </div>
        </div>
      </section>

      {/* 5. ACADEMY MILESTONES STRIP (UNCHANGED 4 METRIC BOX) */}
      <section className="bg-[#FAF5EA] p-3 sm:p-4 rounded-2xl border-2 border-[#E5B842]/50 grid grid-cols-4 gap-2 text-center shadow-xs">
        <div className="flex flex-col items-center">
          <Trophy size={16} className="text-[#1A3D73]" />
          <span className="text-[10px] font-extrabold text-[#8C681E] uppercase mt-0.5">Points</span>
          <div className="font-black text-xs sm:text-sm text-[#0A192F] font-mono tabular-nums">
            {progress.totalPoints}
          </div>
        </div>

        <div className="flex flex-col items-center">
          <Zap size={16} className="text-[#B8892B]" />
          <span className="text-[10px] font-extrabold text-[#8C681E] uppercase mt-0.5">Quest XP</span>
          <div className="font-black text-xs sm:text-sm text-[#0A192F] font-mono tabular-nums">
            {progress.xp}
          </div>
        </div>

        <div className="flex flex-col items-center">
          <MapIcon size={16} className="text-[#1A3D73]" />
          <span className="text-[10px] font-extrabold text-[#8C681E] uppercase mt-0.5">Realms</span>
          <div className="font-black text-xs sm:text-sm text-[#0A192F] font-mono tabular-nums">
            {unlockedCount}/{currentModules.length}
          </div>
        </div>

        <div className="flex flex-col items-center">
          <Shield size={16} className="text-[#D4AF37]" />
          <span className="text-[10px] font-extrabold text-[#8C681E] uppercase mt-0.5">Level</span>
          <div className="font-black text-xs sm:text-sm text-[#0A192F]">
            Lv. {progress.level}
          </div>
        </div>
      </section>
    </div>
  );
};
