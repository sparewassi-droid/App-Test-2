import React, { useState, useMemo } from 'react';
import {
  Compass,
  Award,
  Lock,
  ArrowRight,
  X,
  Map as MapIcon,
  Sparkles,
  Star,
  CheckCircle2,
  Play,
  Trophy,
  ChevronRight,
  Scroll,
} from 'lucide-react';
import {
  AgeGroup,
  Tier,
  ProgressState,
  ModuleDefinition,
} from '../../../types';
import { MODULE_DEFINITIONS } from '../../../data/modules';
import { TreasureChestSvg, TreasureState } from './TreasureChestSvg';
import { QuestScrollModal } from './QuestScrollModal';
import { checkAllSealsEarned, isRegionUnlocked } from '../../../utils/unlockRules';
import { soundService } from '../../../utils/audio';

interface QuestMapProps {
  progress: ProgressState;
  ageGroup: AgeGroup;
  onSelectStage: (moduleId: string, tier: Tier) => void;
  onBackToMode: () => void;
  onChangeAgeGroup?: (age: AgeGroup) => void;
}

interface PositionCoord {
  left: string;
  top: string;
  svgX: number;
  svgY: number;
}

// Generate well-spaced map coordinates avoiding any overlap between adjacent quests
function getQuestCoordinates(count: number): PositionCoord[] {
  if (count <= 4) {
    return [
      { left: '18%', top: '78%', svgX: 180, svgY: 510 }, // 1. Oasis (Bottom-Left)
      { left: '80%', top: '74%', svgX: 800, svgY: 480 }, // 2. Canyon (Bottom-Right)
      { left: '78%', top: '34%', svgX: 780, svgY: 220 }, // 3. Grove (Mid-Right)
      { left: '22%', top: '24%', svgX: 220, svgY: 160 }, // 4. Harbor (Upper-Left)
    ];
  }
  if (count === 5) {
    return [
      { left: '16%', top: '80%', svgX: 160, svgY: 520 }, // 1. Oasis (Bottom-Left)
      { left: '80%', top: '75%', svgX: 800, svgY: 490 }, // 2. Canyon (Bottom-Right)
      { left: '30%', top: '52%', svgX: 300, svgY: 340 }, // 3. Steps & Dunes (Mid-Left)
      { left: '82%', top: '34%', svgX: 820, svgY: 220 }, // 4. Olive Grove & Tower (Mid-Right)
      { left: '20%', top: '22%', svgX: 200, svgY: 145 }, // 5. Coastal Harbor (Upper-Left)
    ];
  }
  // 6 or more (Scholar 11–14)
  return [
    { left: '16%', top: '82%', svgX: 160, svgY: 535 }, // 1. Oasis (Bottom-Left)
    { left: '82%', top: '78%', svgX: 820, svgY: 510 }, // 2. Canyon (Bottom-Right)
    { left: '28%', top: '60%', svgX: 280, svgY: 390 }, // 3. Caravanserai (Lower-Mid Left)
    { left: '80%', top: '44%', svgX: 800, svgY: 285 }, // 4. Mountain Fortress (Upper-Mid Right)
    { left: '22%', top: '26%', svgX: 220, svgY: 170 }, // 5. Maritime Port (Upper-Left)
    { left: '72%', top: '18%', svgX: 720, svgY: 120 }, // 6. Andalusian Gardens (Upper-Right)
  ];
}

export const QuestMap: React.FC<QuestMapProps> = ({
  progress,
  ageGroup,
  onSelectStage,
  onBackToMode,
  onChangeAgeGroup,
}) => {
  const [viewMode, setViewMode] = useState<'trail' | 'map'>('trail');
  const [selectedModuleId, setSelectedModuleId] = useState<string | null>(null);
  const [lockedNotice, setLockedNotice] = useState<{
    questNumber: number;
    title: string;
    prevTitle: string;
    prevModuleId: string;
  } | null>(null);

  // Filter modules by current ageGroup
  const moduleDefs = useMemo(() => {
    return Object.values(MODULE_DEFINITIONS).filter((m) => m.ageGroup === ageGroup);
  }, [ageGroup]);

  const allSealsEarned = checkAllSealsEarned(moduleDefs, progress.modules);

  // Determine unlock state for each quest module
  const questStates = useMemo(() => {
    return moduleDefs.map((mod, idx) => {
      const isUnlocked = isRegionUnlocked(
        idx,
        moduleDefs,
        progress.modules,
        progress.grownUps.allRegionsUnlocked
      );
      const prog = progress.modules[mod.id];
      const easyPassed = !!prog?.stages.easy.passed;
      const moderatePassed = !!prog?.stages.moderate.passed;
      const difficultPassed = !!prog?.stages.difficult.passed;
      const isMastered = easyPassed && moderatePassed && difficultPassed;
      const stars = (prog?.stages.easy.stars || 0) +
        (prog?.stages.moderate.stars || 0) +
        (prog?.stages.difficult.stars || 0);

      let visualState: TreasureState = 'locked';
      if (!isUnlocked) {
        visualState = 'locked';
      } else if (isMastered) {
        visualState = 'mastered';
      } else {
        visualState = 'active';
      }

      return {
        mod,
        isUnlocked,
        isMastered,
        stars,
        visualState,
      };
    });
  }, [moduleDefs, progress.modules, progress.grownUps.allRegionsUnlocked]);

  // Active quest is the first unlocked quest that is not yet fully mastered
  const activeQuestIndex = useMemo(() => {
    const idx = questStates.findIndex((q) => q.isUnlocked && !q.isMastered);
    return idx !== -1 ? idx : questStates.length;
  }, [questStates]);

  const coords = useMemo(() => getQuestCoordinates(moduleDefs.length), [moduleDefs.length]);

  const getSafePosition = (idx: number): PositionCoord => {
    return coords[idx] || {
      left: `${20 + idx * 15}%`,
      top: `${30 + (idx % 2) * 35}%`,
      svgX: 200 + idx * 120,
      svgY: 250 + (idx % 2) * 180,
    };
  };

  const handleQuestNodeClick = (idx: number) => {
    soundService.playTap();
    const qState = questStates[idx];
    if (!qState) return;

    if (!qState.isUnlocked) {
      const prevMod = idx > 0 ? questStates[idx - 1]?.mod : null;
      setLockedNotice({
        questNumber: idx + 1,
        title: qState.mod.title,
        prevTitle: prevMod ? prevMod.title : 'Prior Realm',
        prevModuleId: prevMod ? prevMod.id : moduleDefs[0].id,
      });
      return;
    }

    setSelectedModuleId(qState.mod.id);
  };

  const inspectingModule = selectedModuleId
    ? moduleDefs.find((m) => m.id === selectedModuleId) || null
    : null;
  const inspectingIndex = inspectingModule
    ? moduleDefs.findIndex((m) => m.id === inspectingModule.id)
    : -1;

  // Position for the Summit Apex
  const apexPos = useMemo(() => {
    if (moduleDefs.length <= 4) {
      return { left: '50%', top: '12%', svgX: 500, svgY: 80 };
    }
    if (moduleDefs.length === 5) {
      return { left: '52%', top: '11%', svgX: 520, svgY: 75 };
    }
    return { left: '52%', top: '12%', svgX: 520, svgY: 80 };
  }, [moduleDefs.length]);

  return (
    <div className="relative h-full w-full flex flex-col bg-[#F3E7CC] text-[#1B2A41] overflow-hidden select-none font-sans">
      {/* 1. TOP HEADER: AGE GROUP SELECTOR + MODERN VIEW TOGGLE */}
      <header className="shrink-0 header-safe glass-surface border-b border-[#D4AF37]/35 dark:border-emerald-700/50 px-3 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-2 shadow-xs z-30 select-none">
        {/* Left: Age Group Selector */}
        <div className="flex bg-[#ECE0C7] p-1 rounded-2xl border border-[#D4AF37]/50 shadow-inner max-w-xs justify-center gap-1">
          <button
            type="button"
            onClick={() => {
              soundService.playTap();
              onChangeAgeGroup?.('7-11');
              setSelectedModuleId(null);
              setLockedNotice(null);
            }}
            className={`py-1 px-2.5 sm:px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              ageGroup === '7-11'
                ? 'bg-gradient-to-r from-[#1A3D73] to-[#2556A3] text-white shadow-md border border-[#E5B842]'
                : 'text-[#8C681E] hover:text-[#10264F]'
            }`}
          >
            <Compass size={14} className={ageGroup === '7-11' ? 'text-[#F5C542]' : 'text-[#8C681E]'} />
            <span>Explorer</span>
            <span
              className={`text-[9px] px-1 py-0.2 rounded font-bold leading-none ${
                ageGroup === '7-11' ? 'bg-[#10264F] text-[#FFF0A6]' : 'bg-[#DFD0B0] text-[#7A6133]'
              }`}
            >
              7–11
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundService.playTap();
              onChangeAgeGroup?.('11-14');
              setSelectedModuleId(null);
              setLockedNotice(null);
            }}
            className={`py-1 px-2.5 sm:px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              ageGroup === '11-14'
                ? 'bg-gradient-to-r from-[#C99726] to-[#B8892B] text-white shadow-md border border-[#FFF0A6]'
                : 'text-[#8C681E] hover:text-[#10264F]'
            }`}
          >
            <Award size={14} className={ageGroup === '11-14' ? 'text-[#FFF0A6]' : 'text-[#8C681E]'} />
            <span>Scholar</span>
            <span
              className={`text-[9px] px-1 py-0.2 rounded font-bold leading-none ${
                ageGroup === '11-14' ? 'bg-[#855F10] text-[#FFF0A6]' : 'bg-[#DFD0B0] text-[#7A6133]'
              }`}
            >
              11–14
            </span>
          </button>
        </div>

        {/* Right: Modern View Toggle (Trail Path vs Illustrated Map) */}
        <div className="flex bg-[#ECE0C7] p-1 rounded-2xl border border-[#D4AF37]/50 shadow-inner gap-1">
          <button
            type="button"
            onClick={() => {
              soundService.playTap();
              setViewMode('trail');
            }}
            className={`py-1 px-2.5 sm:px-3 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'trail'
                ? 'bg-[#1A3D73] text-white shadow-sm border border-[#E5B842]'
                : 'text-[#8C681E] hover:text-[#10264F]'
            }`}
          >
            <Scroll size={13} className={viewMode === 'trail' ? 'text-[#F5C542]' : 'currentColor'} />
            <span>Trail Path</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundService.playTap();
              setViewMode('map');
            }}
            className={`py-1 px-2.5 sm:px-3 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              viewMode === 'map'
                ? 'bg-[#1A3D73] text-white shadow-sm border border-[#E5B842]'
                : 'text-[#8C681E] hover:text-[#10264F]'
            }`}
          >
            <MapIcon size={13} className={viewMode === 'map' ? 'text-[#F5C542]' : 'currentColor'} />
            <span>World Map</span>
          </button>
        </div>
      </header>

      {/* 2. BODY CONTENT: SCROLLABLE TRAIL OR ILLUSTRATED MAP */}
      {viewMode === 'trail' ? (
        /* ======================== SCROLLABLE JOURNEY TRAIL VIEW ======================== */
        <div className="flex-1 w-full h-full overflow-y-auto overscroll-contain px-3 sm:px-6 py-4 pb-28 sm:pb-32 max-w-2xl mx-auto space-y-4 text-[#10264F]">
          {/* Trail Header Banner */}
          <div className="glass-surface p-4 rounded-3xl border border-[#D4AF37]/40 shadow-xs flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-[#8C681E]">
                <Sparkles size={13} className="text-[#D4AF37]" />
                <span>Expedition Progress</span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-[#10264F] mt-0.5">
                {ageGroup === '7-11' ? 'Explorer Saga Trail (7–11)' : 'Scholar Mastery Trail (11–14)'}
              </h2>
              <p className="text-xs text-[#5B6B7B] mt-0.5">
                Complete Core Trial in each realm to unlock the next quest checkpoint.
              </p>
            </div>

            <div className="text-right shrink-0">
              <span className="text-xs font-extrabold text-[#8C681E] block">Mastery Seals</span>
              <span className="text-base sm:text-lg font-black text-[#1A3D73]">
                {questStates.filter((q) => q.isMastered).length} / {moduleDefs.length} 🏆
              </span>
            </div>
          </div>

          {/* Sequential Station Cards in the Trail */}
          <div className="space-y-4">
            {questStates.map((qState, idx) => {
              const { mod, isUnlocked, isMastered, stars } = qState;
              const isCurrent = activeQuestIndex === idx;
              const mProg = progress.modules[mod.id];

              return (
                <div
                  key={mod.id}
                  className={`glass-surface rounded-3xl border p-4 sm:p-5 transition-all shadow-sm ${
                    !isUnlocked
                      ? 'opacity-65 border-[#E5E7EB] bg-[#F4EDE0]'
                      : isCurrent
                      ? 'border-[#2A5CAA] ring-2 ring-[#E5B842]/70 shadow-md'
                      : isMastered
                      ? 'border-[#D4AF37] bg-white/95'
                      : 'border-[#E4D6BA]'
                  }`}
                >
                  {/* Station Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="p-1 rounded-2xl bg-[#F6EACF] border border-[#D4AF37] shadow-inner flex items-center justify-center shrink-0">
                        <TreasureChestSvg
                          state={qState.visualState}
                          size={46}
                          isCurrent={isCurrent}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-black uppercase tracking-wider text-[#8C681E]">
                            Quest {idx + 1} • {mod.regionName}
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] font-black text-white bg-[#1A3D73] px-2 py-0.2 rounded-full border border-[#E5B842]">
                              Active Checkpoint
                            </span>
                          )}
                        </div>

                        <h3 className="text-base sm:text-lg font-black text-[#10264F] flex items-center gap-2 mt-0.5">
                          <span>{mod.title}</span>
                          {mod.arabicSubtitle && (
                            <span className="font-amiri text-xs text-[#8C681E] bg-[#FAF5EA] px-2 py-0.2 rounded border border-[#E5C568]/40">
                              {mod.arabicSubtitle}
                            </span>
                          )}
                        </h3>
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      {isMastered ? (
                        <span className="text-xs font-black text-[#B45309] bg-[#FEF3C7] border border-[#FDE68A] px-2.5 py-1 rounded-full flex items-center gap-1">
                          <Trophy size={13} /> Mastered
                        </span>
                      ) : isUnlocked ? (
                        <span className="text-xs font-black text-[#D4AF37] bg-[#FDF5E2] border border-[#E5C568] px-2.5 py-1 rounded-full">
                          ★ {stars}/9 Stars
                        </span>
                      ) : (
                        <span className="text-xs font-bold text-[#6B7280] bg-[#F3F4F6] px-2.5 py-1 rounded-full flex items-center gap-1">
                          <Lock size={12} /> Locked
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-[#5B6B7B] mt-2 font-medium">
                    {mod.description}
                  </p>

                  {/* 3 Stage Checkpoints (Easy, Moderate, Difficult) */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-[#E5C568]/40">
                    {(['easy', 'moderate', 'difficult'] as Tier[]).map((tierKey) => {
                      const tierProgress = mProg?.stages[tierKey];
                      const isPassed = !!tierProgress?.passed;
                      const tierStars = tierProgress?.stars || 0;
                      const tierLabel =
                        tierKey === 'easy'
                          ? 'Trial I (Easy)'
                          : tierKey === 'moderate'
                          ? 'Trial II (Core)'
                          : 'Trial III (Mastery)';

                      return (
                        <button
                          key={tierKey}
                          type="button"
                          disabled={!isUnlocked}
                          onClick={() => {
                            if (isUnlocked) {
                              soundService.playTap();
                              onSelectStage(mod.id, tierKey);
                            }
                          }}
                          className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1.5 transition-all ${
                            !isUnlocked
                              ? 'opacity-50 cursor-not-allowed bg-black/5 border-transparent'
                              : isPassed
                              ? 'bg-[#FDF5E2] border-[#D4AF37] hover:border-[#B8892B] cursor-pointer'
                              : 'bg-white border-[#E4D6BA] hover:border-[#1A3D73] cursor-pointer shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[11px] font-black">
                            <span className={isPassed ? 'text-[#8C681E]' : 'text-[#10264F]'}>
                              {tierLabel}
                            </span>
                            {isPassed ? (
                              <CheckCircle2 size={13} className="text-[#16A34A]" />
                            ) : (
                              <Play size={11} className="text-[#1A3D73]" />
                            )}
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-[#5B6B7B]">
                            <span>
                              {tierKey === 'moderate' ? '20 Questions' : '10 Questions'}
                            </span>
                            <span className="font-bold text-[#D4AF37]">
                              ★ {tierStars}/3
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}

            {/* Summit Apex Crown Node */}
            <div className="glass-surface rounded-3xl border-2 border-[#D4AF37] p-5 text-center shadow-md bg-gradient-to-b from-[#FFFDF7] to-[#FDF5E2]">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#FDF5E2] border-2 border-[#D4AF37] flex items-center justify-center text-2xl shadow-sm mb-2">
                👑
              </div>
              <h3 className="text-base sm:text-lg font-black text-[#10264F]">
                The Sultan’s Summit Vault (Apex)
              </h3>
              <p className="text-xs text-[#5B6B7B] max-w-md mx-auto mt-1">
                {allSealsEarned
                  ? 'MashaAllah! You have cleared every realm and attained the Royal Academy Seal!'
                  : 'Master all quests along the expedition trail to unlock the Summit Crown.'}
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* ======================== ILLUSTRATED REALM MAP VIEW ======================== */
        <div className="flex-1 w-full h-full relative overflow-hidden flex items-center justify-center p-1 sm:p-2.5">
          <div
            className="relative w-full h-full max-w-5xl rounded-3xl border-4 border-[#D4AF37] bg-[#F7EED8] shadow-2xl overflow-hidden"
            style={{
              boxShadow: '0 20px 45px -10px rgba(26, 61, 124, 0.4), inset 0 0 60px rgba(212, 175, 55, 0.28)',
            }}
          >
            {/* SVG MAP BACKGROUND: TERRAIN, WATER, AND WINDING DOTTED TREASURE TRAIL */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              preserveAspectRatio="none"
              viewBox="0 0 1000 650"
            >
              <defs>
                <radialGradient id="parchmentTexture" cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor="#FFF9EB" />
                  <stop offset="60%" stopColor="#F5E8C7" />
                  <stop offset="100%" stopColor="#E3CCA0" />
                </radialGradient>
                <filter id="goldPathGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor="#F1C40F" floodOpacity="0.8" />
                </filter>
              </defs>

              <rect width="1000" height="650" fill="url(#parchmentTexture)" />

              {/* Weathered Outer Compass Border */}
              <rect
                x="12"
                y="12"
                width="976"
                height="626"
                rx="20"
                fill="none"
                stroke="#B89454"
                strokeWidth="2.5"
                strokeDasharray="18 10"
                opacity="0.65"
              />
              <rect
                x="20"
                y="20"
                width="960"
                height="610"
                rx="16"
                fill="none"
                stroke="#CFA968"
                strokeWidth="1"
                opacity="0.4"
              />

              {/* Contours & Water features */}
              <ellipse cx="160" cy="520" rx="135" ry="70" fill="#D3EBF5" opacity="0.65" />
              <ellipse cx="160" cy="520" rx="95" ry="45" fill="#BFE3F2" opacity="0.55" />
              <polygon points="720,560 760,470 800,560" fill="#E6BA80" opacity="0.5" />
              <polygon points="770,560 810,450 850,560" fill="#DEAB6D" opacity="0.5" />
              <polygon points="820,560 860,480 900,560" fill="#E6BA80" opacity="0.5" />
              <ellipse cx="300" cy="340" rx="110" ry="60" fill="#EFE0BC" opacity="0.45" />
              <ellipse cx="810" cy="225" rx="125" ry="75" fill="#E2E8D0" opacity="0.5" />
              <ellipse cx="190" cy="155" rx="135" ry="75" fill="#D5EEF5" opacity="0.55" />
              <polygon points="430,135 520,40 610,135" fill="#E2C99D" opacity="0.6" />
              <polygon points="480,135 520,75 560,135" fill="#FFF9ED" opacity="0.8" />

              {/* DYNAMIC WINDING DOTTED TREASURE TRAIL */}
              {questStates.map((_, i) => {
                if (i >= questStates.length - 1) return null;
                const p = getSafePosition(i);
                const nextP = getSafePosition(i + 1);
                const isSegmentUnlocked = !!questStates[i + 1]?.isUnlocked;

                const midX = (p.svgX + nextP.svgX) / 2;
                const midY = (p.svgY + nextP.svgY) / 2 + (i % 2 === 0 ? 30 : -25);
                const pathD = `M ${p.svgX} ${p.svgY} Q ${midX} ${midY} ${nextP.svgX} ${nextP.svgY}`;

                return (
                  <path
                    key={`trail-seg-${i}`}
                    d={pathD}
                    fill="none"
                    stroke={isSegmentUnlocked ? '#D4AF37' : '#1A3D73'}
                    strokeWidth={isSegmentUnlocked ? '6' : '3.5'}
                    strokeDasharray={isSegmentUnlocked ? '10 8' : '8 8'}
                    strokeLinecap="round"
                    filter={isSegmentUnlocked ? 'url(#goldPathGlow)' : undefined}
                    opacity={isSegmentUnlocked ? 0.95 : 0.45}
                  />
                );
              })}

              {/* Apex trail */}
              {(() => {
                const lastPos = getSafePosition(questStates.length - 1);
                const midX = (lastPos.svgX + apexPos.svgX) / 2;
                const midY = (lastPos.svgY + apexPos.svgY) / 2;
                const pathD = `M ${lastPos.svgX} ${lastPos.svgY} Q ${midX} ${midY} ${apexPos.svgX} ${apexPos.svgY}`;

                return (
                  <path
                    d={pathD}
                    fill="none"
                    stroke={allSealsEarned ? '#D4AF37' : '#1A3D73'}
                    strokeWidth={allSealsEarned ? '6' : '3.5'}
                    strokeDasharray={allSealsEarned ? '10 8' : '8 8'}
                    strokeLinecap="round"
                    filter={allSealsEarned ? 'url(#goldPathGlow)' : undefined}
                    opacity={allSealsEarned ? 0.95 : 0.45}
                  />
                );
              })()}

              {/* Big X for Summit */}
              <g transform={`translate(${apexPos.svgX}, ${apexPos.svgY - 2})`} opacity={allSealsEarned ? 0.95 : 0.6}>
                <line x1="-20" y1="-20" x2="20" y2="20" stroke="#C0392B" strokeWidth="6" strokeLinecap="round" />
                <line x1="20" y1="-20" x2="-20" y2="20" stroke="#C0392B" strokeWidth="6" strokeLinecap="round" />
              </g>
            </svg>

            {/* INTERACTIVE QUEST WAYPOINT TREASURES ON THE MAP */}
            {questStates.map((qState, idx) => {
              const pos = getSafePosition(idx);
              const isCurrentPin = activeQuestIndex === idx;

              return (
                <div
                  key={qState.mod.id}
                  style={{ left: pos.left, top: pos.top }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer group select-none"
                  onClick={() => handleQuestNodeClick(idx)}
                >
                  {isCurrentPin && (
                    <div className="absolute -top-11 z-30 pointer-events-none animate-bounce-gentle flex flex-col items-center">
                      <div className="px-2 py-0.5 rounded-full bg-gradient-to-r from-[#1A3D73] to-[#2A5CAA] text-[#FFF0A6] text-[9px] font-black shadow-md border-2 border-[#E5B842] flex items-center gap-1 whitespace-nowrap">
                        <span>You are here</span>
                      </div>
                      <div className="w-6 h-6 rounded-full bg-[#1A3D73] border-2 border-[#E5B842] shadow-lg flex items-center justify-center text-[#FFF0A6] text-[10px] font-black -mt-0.5">
                        {progress.username.substring(0, 1).toUpperCase()}
                      </div>
                    </div>
                  )}

                  <div
                    className={`relative p-1 rounded-2xl transition-all duration-300 flex items-center justify-center ${
                      qState.visualState === 'active'
                        ? 'scale-105 group-hover:scale-115'
                        : qState.visualState === 'mastered'
                        ? 'group-hover:scale-110'
                        : 'opacity-80 group-hover:opacity-95'
                    }`}
                  >
                    {qState.visualState === 'active' && (
                      <div className="absolute inset-0 rounded-full bg-[#F5C542]/35 animate-ping pointer-events-none" />
                    )}
                    <TreasureChestSvg
                      state={qState.visualState}
                      size={52}
                      isCurrent={isCurrentPin}
                    />
                  </div>

                  <div
                    className={`-mt-1 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-xl border-2 flex flex-col items-center shadow-md text-center w-[105px] xs:w-[118px] sm:w-[132px] transition-all select-none ${
                      qState.visualState === 'locked'
                        ? 'bg-[#EAE0CA]/95 border-[#C7B591] text-[#7A6B4F]'
                        : qState.visualState === 'mastered'
                        ? 'bg-[#FDF5E2] border-2 border-[#D4AF37] text-[#8C681E]'
                        : 'bg-white border-2 border-[#1A3D73] text-[#10264F] ring-2 ring-[#E5B842] shadow-lg'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <span className="text-[8px] sm:text-[9px] font-black uppercase tracking-wider text-[#1A3D73]">
                        Quest {idx + 1}
                      </span>
                      {qState.visualState === 'locked' ? (
                        <Lock size={9} className="text-[#8C7A5C]" />
                      ) : (
                        <span className="text-[8px] sm:text-[9px] font-black text-[#D4AF37]">
                          ★ {qState.stars}/9
                        </span>
                      )}
                    </div>
                    <span className="text-[9px] sm:text-[10px] font-black truncate w-full leading-tight">
                      {qState.mod.title}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* SUMMIT APEX VAULT */}
            <div
              style={{ left: apexPos.left, top: apexPos.top }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer group select-none"
              onClick={() => {
                soundService.playTap();
                const lastMod = questStates[questStates.length - 1]?.mod;
                if (!allSealsEarned) {
                  setLockedNotice({
                    questNumber: questStates.length + 1,
                    title: 'The Sultan’s Summit Vault (Apex)',
                    prevTitle: lastMod ? lastMod.title : 'Prior Quest',
                    prevModuleId: lastMod ? lastMod.id : moduleDefs[0].id,
                  });
                } else if (lastMod) {
                  setSelectedModuleId(lastMod.id);
                }
              }}
            >
              <TreasureChestSvg
                state="apex"
                size={58}
                isCurrent={allSealsEarned}
              />
              <div className="mt-0.5 px-2.5 py-0.5 rounded-xl border border-[#D4AF37] bg-[#FDF5E2] text-xs font-black text-[#8C681E]">
                Summit Vault
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. QUEST SCROLL MODAL (APPEARS WHEN PLAYER TAPS AN OPEN QUEST) */}
      {inspectingModule && (
        <QuestScrollModal
          moduleDef={inspectingModule}
          questIndex={inspectingIndex}
          moduleProgress={progress.modules[inspectingModule.id]}
          allRegionsUnlocked={progress.grownUps.allRegionsUnlocked}
          onClose={() => setSelectedModuleId(null)}
          onSelectStage={onSelectStage}
        />
      )}

      {/* 4. LOCKED TREASURE NOTIFICATION */}
      {lockedNotice && (
        <div
          role="alertdialog"
          className="fixed inset-x-4 bottom-14 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:bottom-16 z-50 max-w-md w-full bg-[#FFFDF7] rounded-3xl border-2 border-[#1A3D73] p-4 shadow-2xl animate-fade-in flex items-center justify-between gap-3 select-none"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#EAF2FD] border border-[#1A3D73] flex items-center justify-center text-[#1A3D73] shrink-0">
              <Lock size={20} />
            </div>
            <div>
              <h4 className="text-sm font-black text-[#10264F]">
                Treasure #{lockedNotice.questNumber} is Locked!
              </h4>
              <p className="text-xs text-[#5B6B7B] mt-0.5 leading-tight">
                Complete Core Trial of{' '}
                <span className="font-bold text-[#10264F]">{lockedNotice.prevTitle}</span> along the trail to unlock.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                setSelectedModuleId(lockedNotice.prevModuleId);
                setLockedNotice(null);
              }}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#1A3D73] to-[#2556A3] text-white text-xs font-black flex items-center gap-1 hover:brightness-105 transition-all shadow-xs cursor-pointer"
            >
              <span>Play Prior</span>
              <ArrowRight size={13} className="text-[#FFF0A6]" />
            </button>
            <button
              type="button"
              onClick={() => setLockedNotice(null)}
              className="p-1 rounded-lg text-[#5B6B7B] hover:text-[#10264F] cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Animation Styles */}
      <style>{`
        @keyframes gentleHop {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-7px); }
        }
        .animate-bounce-gentle {
          animation: gentleHop 1.6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
